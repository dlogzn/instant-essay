<div id="ajax_loading">
    <div class="ajax_loading_spinner">
        <div class="loading_spinner"></div>
    </div>

</div>
