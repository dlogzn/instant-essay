<div class="container-fluid" style="background-color: #fbf5ff;">
    <div class="row py-5">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 mx-auto">
            <div class="row mt-3">
                <div class="col text-center ">
                    <span class="text_color_default">&copy; {{ date('Y') }} Instant Essay</span>
                </div>
            </div>
        </div>
    </div>
</div>
