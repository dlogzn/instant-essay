<div class="container-fluid">
    <div class="row py-4">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 mx-auto">
            <div class="row">
                <div class="col text-center ">
                    <span class="text_color_default">&copy; {{ date('Y') }} Instant Essay</span>
                </div>
            </div>
        </div>
    </div>
</div>
