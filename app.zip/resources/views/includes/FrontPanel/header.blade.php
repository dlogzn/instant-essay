<div class="container-fluid">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 mx-auto">
            <div class="d-flex justify-content-center justify-content-lg-start py-2">
                <a href="{{ url('/') }}"><span style="cursor: pointer; height: 30px;"><img src="{{ asset('/storage/images/default/logo.png') }}" height="100"></span></a>
            </div>
        </div>
    </div>
</div>


