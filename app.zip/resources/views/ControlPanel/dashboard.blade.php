@extends('layouts.control_panel')

@section('content')
    <div style="min-height: 500px;">

    </div>

@endsection
